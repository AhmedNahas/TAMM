package net.middledleeast.tamm;

import android.app.Activity;

public class LanguageActivity extends Activity {
}
