package payments;

public class Constants {
    public final static String URL_EE_TEST = "https://api-test.wirecard.com";
    public final static int REQUEST_TIMEOUT = 30;
}
