package FlightApi;

public class FlightResponses {
}
