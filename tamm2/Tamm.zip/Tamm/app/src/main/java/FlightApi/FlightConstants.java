package FlightApi;

public class FlightConstants {


    public static final String API_USER_NAME = "Apptamm";

}
